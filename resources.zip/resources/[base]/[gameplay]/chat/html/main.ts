import Vue from 'vue';
import App from './App.vue';

const instance = new Vue({
    el: '#app',
    render: h => h(App),
});