money_fountain 'test_fountain' {
    vector3(97.334, -973.621, 29.36),
    amount = 75
}