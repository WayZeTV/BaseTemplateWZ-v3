Locales['nl'] = {
  ['invoices'] = 'Facturen',
  ['invoices_item'] = '€%s',
  ['received_invoice'] = 'Je hebt zojuist een ~r~factuur ontvangen',
  ['paid_invoice'] = 'Je hebt een factuur betaald van ~r~€%s',
  ['no_invoices'] = 'Je hoeft momenteel geen facturen te betalen',
  ['received_payment'] = 'je hebt een bedrag ontvangen van ~r~€%s',
  ['player_not_online'] = 'de speler is niet online',
  ['no_money'] = 'je hebt niet genoeg geld om deze factuur te betalen',
  ['target_no_money'] = 'de speler ~r~heeft niet genoeg geld om te betalen!',
  ['keymap_showbills'] = 'open factuur menu',
}
