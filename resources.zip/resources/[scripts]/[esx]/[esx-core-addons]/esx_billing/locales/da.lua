Locales['da'] = {
    ['invoices'] = 'regninger',
    ['invoices_item'] = 'DKK%s',
    ['received_invoice'] = 'du har lige ~r~modtaget en faktura',
    ['paid_invoice'] = 'du har betalt en faktura på ~r~DKK%s',
    ['no_invoices'] = 'du har ingen regninger at betale i øjeblikket',
    ['received_payment'] = 'du har modtaget en betaling på ~r~DKK%s',
    ['player_not_online'] = 'spilleren er ikke online',
    ['no_money'] = 'du har ikke penge nok til at betale denne regning',
    ['target_no_money'] = 'spilleren ~r~har ikke penge nok til at betale regningen!',
    ['keymap_showbills'] = 'åbne regninger menu',
  }