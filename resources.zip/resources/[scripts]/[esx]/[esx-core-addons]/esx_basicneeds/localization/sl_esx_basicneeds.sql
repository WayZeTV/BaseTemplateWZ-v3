INSERT INTO `items` (`name`, `label`, `weight`) VALUES
    ('bread', 'Kruh', 1),
    ('water', 'Voda', 1)
;
