Locales['tr'] = {
    ['used_food'] = '%s adet yemek yediniz',
    ['used_drink'] = '%s adet içecek içtiniz',
    ['got_healed'] = 'İyileştirildiniz.'
}
  