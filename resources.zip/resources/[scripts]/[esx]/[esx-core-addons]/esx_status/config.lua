Config = {}

Config.StatusMax      = 1000000
Config.TickTime       = 1000
Config.UpdateInterval = 30000
Config.Display        = false	-- Enable the esx_status bars (disable if you are using another HUD)
