Config              = {}

Config.allowedJobs  = {
	['police'] = true
}